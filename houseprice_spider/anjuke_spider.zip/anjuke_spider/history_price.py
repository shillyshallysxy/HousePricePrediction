class HisPrice(object):
    def __init__(self, time_, price, compare):
        # self.city = city
        self.time = time_
        self.price = price
        self.compare = compare

    def get_list(self):
        his_price = list()
        # his_price.append(self.city)
        his_price.append(self.time)
        his_price.append(self.price)
        his_price.append(self.compare)
        return his_price
