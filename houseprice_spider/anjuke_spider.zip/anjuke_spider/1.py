import threadpool
from bs4 import BeautifulSoup
from history_price import HisPrice
import re
def hello(a, b):
    """"""
    print(a, b)
    # print("m = %s, n = %s, o = %s" % (m, n, o))


if __name__ == '__main__':

    with open('test.txt', 'rb') as f:
        content = f.read().decode('utf-8')
    soup = BeautifulSoup(content, 'lxml')
    ul_list = soup.find_all('div', class_='fjlist-box boxstyle2')[0]
    ul_list = ul_list.find('ul')
    ul_list = ul_list.find_all('li')
    hos_price_list = list()
    for ul in ul_list:
        title = ul.find('b').text
        price = ul.find('span').text
        compare = ul.find('em').text
        hos_price_list.append(HisPrice(title, price, compare).get_list())

    a = re.sub('2019', str(2018), 'http://www.anjuke.com/fangjia/huaian2019/jingjikaifaquabcde/')
    print(1)